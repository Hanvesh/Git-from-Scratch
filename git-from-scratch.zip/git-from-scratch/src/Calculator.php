<?php

namespace Calculator;

use Calculator\Operations\Exponent;

class Calculator
{
    function exponent($num, $exponent): int
    {
        $exponentObj = new Exponent($num, $exponent);
        return $exponentObj->compute();
    }

    // Write your functions below

}
