<?php

namespace Calculator\Operations;

/**
 * @author Nikhil Parakh <nikhil.parakh@mpokket.com>
 */
class Percentage
{

}