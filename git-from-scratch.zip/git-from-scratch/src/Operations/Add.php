<?php

namespace Calculator\Operations;

/**
 * @author Divya <divya.pitti@mpokket.com>
 */
class Add
{

}