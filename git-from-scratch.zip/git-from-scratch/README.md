# git-from-scratch

By Got Your Backs

## Usage

`php index.php <operation> <param1> <param2> <param2> ...`


### Exponent

To get the exponent value for a number,

```
Syntax: `php index.php exponent number number`
Example `php index.php exponent 2 3`
The above example will print `8`
```